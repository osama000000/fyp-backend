export const CONSTANTS={
    ROLES:{
        ADMIN:"admin",
        SERVICE_PROVIDER: "service-provider",
        SERVICE_USER:   "service-user"
    }
}