interface Location {
  ancestorOrigins: string;
  hash: string;
  host: string;
  hostname: string;
  // Add other properties based on the actual Location interface
}

export default Location;
