export class CreateNearestPumpDto {
    location: string;

    name: string;
}
