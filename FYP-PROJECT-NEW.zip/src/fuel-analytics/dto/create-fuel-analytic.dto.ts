export class CreateFuelAnalyticDto {
  vehicletype: string;

  fueltype: string;

  price: string;

  expectations: string;
}
